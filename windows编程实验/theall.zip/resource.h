//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by theall.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_THEALLTYPE                  129
#define IDB_BITMAP1                     130
#define IDD_DIALOG1                     131
#define IDD_DIALOG2                     132
#define IDD_DIALOG3                     133
#define IDD_DIALOG4                     134
#define IDR_TOOLBAR1                    135
#define IDI_ICON1                       137
#define IDI_ICON2                       138
#define IDI_ICON3                       139
#define IDI_ICON4                       140
#define IDI_ICON5                       141
#define IDD_DIALOG5                     142
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_EDIT3                       1002
#define IDC_BTN_ADD                     1003
#define IDC_BTN_GAME                    1004
#define IDC_BTN_COLOR                   1005
#define IDC_BUTTON1                     1007
#define IDC_BUTTON2                     1008
#define IDM_DIALOG                      32771
#define ID_MENUITEM32772                32772
#define ID_DLL                          32772
#define IDM_GAME                        32773
#define ID_MENUITEM32779                32779
#define ID_MENUITEM32780                32780
#define IDS_TAOGE                       61446
#define IDM_COLOR                       65535

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        143
#define _APS_NEXT_COMMAND_VALUE         32781
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
