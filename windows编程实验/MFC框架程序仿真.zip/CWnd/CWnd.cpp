#include <windows.h>

class CWnd
{
public:
	BOOL CreateEx(DWORD dwExStyle,    // extended window style
				LPCTSTR lpClassName,  // registered class name
				LPCTSTR lpWindowName, // window name
				DWORD dwStyle,        // window style
				int x,                // horizontal position of window
				int y,                // vertical position of window
				int nWidth,           // window width
				int nHeight,          // window height
				HWND hWndParent,      // handle to parent or owner window
				HMENU hMenu,          // menu handle or child identifier
				HINSTANCE hInstance,  // handle to application instance
				LPVOID lpParam);      // window-creation data
	BOOL ShowWindow(int nCmdShow);
	BOOL UpdateWindow();
public:
	HWND m_hWnd;
};

BOOL CWnd::CreateEx(DWORD dwExStyle,  // extended window style
				LPCTSTR lpClassName,  // registered class name
				LPCTSTR lpWindowName, // window name
				DWORD dwStyle,        // window style
				int x,                // horizontal position of window
				int y,                // vertical position of window
				int nWidth,           // window width
				int nHeight,          // window height
				HWND hWndParent,      // handle to parent or owner window
				HMENU hMenu,          // menu handle or child identifier
				HINSTANCE hInstance,  // handle to application instance
				LPVOID lpParam)        // window-creation data
{
	m_hWnd=::CreateWindowEx(dwExStyle,lpClassName,lpWindowName,dwStyle,
		                    x,y,nWidth,nHeight,hWndParent,hMenu,hInstance,lpParam);
	if(m_hWnd!=NULL)
		return TRUE;
	else
		return FALSE;
}

BOOL CWnd::ShowWindow(int nCmdShow)
{
	return ::ShowWindow(m_hWnd,nCmdShow);
}

BOOL CWnd::UpdateWindow()
{
	return ::UpdateWindow(m_hWnd);
}

LRESULT CALLBACK MyWndProc(
  HWND hwnd,      // handle to window
  UINT uMsg,      // message identifier
  WPARAM wParam,  // first message parameter
  LPARAM lParam   // second message parameter
);

int WINAPI WinMain(
  HINSTANCE hInstance,      // handle to current instance
  HINSTANCE hPrevInstance,  // handle to previous instance
  LPSTR lpCmdLine,          // command line
  int nCmdShow              // show state
)
{
	WNDCLASS MyWnd;
	MyWnd.cbClsExtra = NULL;
	MyWnd.cbWndExtra = NULL;
	MyWnd.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	MyWnd.hCursor = LoadCursor(NULL, IDC_ARROW);
	MyWnd.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	MyWnd.hInstance = hInstance;
	MyWnd.lpfnWndProc = MyWndProc;
	MyWnd.lpszClassName = "Hello";
	MyWnd.lpszMenuName = NULL;
	MyWnd.style = CS_HREDRAW | CS_VREDRAW;
    RegisterClass(&MyWnd);

	CWnd wnd;
	wnd.CreateEx(0,"Hello","CWnd", WS_OVERLAPPEDWINDOW, 
				 CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,
		         NULL,NULL,hInstance,NULL);

	wnd.ShowWindow(SW_SHOWNORMAL);
	wnd.UpdateWindow();

	MSG msg;
	while (GetMessage(&msg,NULL,0,0)) //����Ϣ�����л�ȡ��Ϣ
	{
		TranslateMessage(&msg);    //��Ϣ����
    //4.������Ϣ
		DispatchMessage(&msg);     //����Ϣ���͵������ڹ��̡�
	} 

	return 0;
}


LRESULT CALLBACK MyWndProc(
  HWND hwnd,      // handle to window
  UINT uMsg,      // message identifier
  WPARAM wParam,  // first message parameter
  LPARAM lParam   // second message parameter
)
{
	switch (uMsg)
	{
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hwnd,uMsg,wParam,lParam);
	}
	
	return 0;
} 